package com.aimirror.service;

import com.aimirror.dto.TryOnRequest;
import com.aimirror.dto.TryOnResponse;
import com.aimirror.model.TryOnSession;
import com.aimirror.repository.TryOnSessionRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class TryOnService {

    private static final Logger log = LoggerFactory.getLogger(TryOnService.class);

    private final GeminiService geminiService;
    private final TryOnSessionRepository repository;

    public TryOnService(GeminiService geminiService, TryOnSessionRepository repository) {
        this.geminiService = geminiService;
        this.repository = repository;
    }

    // ─────────────────────────────────────────────────────────
    //  Main fitting flow
    // ─────────────────────────────────────────────────────────
    public TryOnResponse runVirtualFitting(TryOnRequest request) {
        TryOnResponse response = new TryOnResponse();

        try {
            log.info("Starting virtual fitting for size: {}", request.getSelectedSize());

            // Step 1 – Analyze size fit
            Map<String, Object> analysis = geminiService.analyzeSizeFit(
                    request.getUserImageBase64(),
                    request.getClothImageBase64(),
                    request.getSelectedSize()
            );

            String fitMatch  = (String)  analysis.get("match");
            String fitReason = (String)  analysis.get("reason");
            Integer fitScore = (Integer) analysis.get("score");

            log.info("Fit analysis: {} (score={})", fitMatch, fitScore);

            // Step 2 – Generate try-on image
            String generatedImage = geminiService.generateTryOnImage(
                    request.getUserImageBase64(),
                    request.getClothImageBase64(),
                    request.getSelectedSize()
            );

            // Step 3 – Persist to MongoDB
            TryOnSession session = new TryOnSession();
            session.setSelectedSize(request.getSelectedSize());
            session.setUserImageBase64(request.getUserImageBase64());
            session.setClothImageBase64(request.getClothImageBase64());
            session.setGeneratedImageBase64(generatedImage);
            session.setFitMatch(fitMatch);
            session.setFitReason(fitReason);
            session.setFitScore(fitScore);
            TryOnSession saved = repository.save(session);

            log.info("Session saved with id: {}", saved.getId());

            // Build response
            response.setSessionId(saved.getId());
            response.setFitMatch(fitMatch);
            response.setFitReason(fitReason);
            response.setFitScore(fitScore);
            response.setGeneratedImageBase64(generatedImage);
            response.setMessage("Virtual fitting completed successfully!");

        } catch (Exception e) {
            log.error("Error during virtual fitting", e);
            response.setMessage("Error: " + e.getMessage());
        }

        return response;
    }

    // ─────────────────────────────────────────────────────────
    //  Fetch all past sessions
    // ─────────────────────────────────────────────────────────
    public List<TryOnSession> getAllSessions() {
        return repository.findAllByOrderByCreatedAtDesc();
    }

    // ─────────────────────────────────────────────────────────
    //  Fetch single session
    // ─────────────────────────────────────────────────────────
    public TryOnSession getSessionById(String id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Session not found: " + id));
    }

    // ─────────────────────────────────────────────────────────
    //  Delete session
    // ─────────────────────────────────────────────────────────
    public void deleteSession(String id) {
        repository.deleteById(id);
    }
}