package com.aimirror.dto;

public class TryOnRequest {

    private String userImageBase64;   // Full data URI: "data:image/png;base64,..."
    private String clothImageBase64;  // Full data URI: "data:image/png;base64,..."
    private String selectedSize;      // "XS", "S", "M", "L", "XL", "XXL"

    public String getUserImageBase64() { return userImageBase64; }
    public void setUserImageBase64(String userImageBase64) { this.userImageBase64 = userImageBase64; }

    public String getClothImageBase64() { return clothImageBase64; }
    public void setClothImageBase64(String clothImageBase64) { this.clothImageBase64 = clothImageBase64; }

    public String getSelectedSize() { return selectedSize; }
    public void setSelectedSize(String selectedSize) { this.selectedSize = selectedSize; }
}