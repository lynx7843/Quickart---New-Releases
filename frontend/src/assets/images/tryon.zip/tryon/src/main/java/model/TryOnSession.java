package com.aimirror.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.time.LocalDateTime;

@Document(collection = "try_on_sessions")  // Change "try_on_sessions" to your collection name
public class TryOnSession {

    @Id
    private String id;

    private String selectedSize;

    // Stored as Base64 strings
    private String userImageBase64;
    private String clothImageBase64;
    private String generatedImageBase64;

    // Gemini analysis result
    private String fitMatch;       // "Perfect", "Tight", "Loose"
    private String fitReason;
    private Integer fitScore;

    private LocalDateTime createdAt;

    // ---------- Constructors ----------
    public TryOnSession() {
        this.createdAt = LocalDateTime.now();
    }

    // ---------- Getters & Setters ----------
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getSelectedSize() { return selectedSize; }
    public void setSelectedSize(String selectedSize) { this.selectedSize = selectedSize; }

    public String getUserImageBase64() { return userImageBase64; }
    public void setUserImageBase64(String userImageBase64) { this.userImageBase64 = userImageBase64; }

    public String getClothImageBase64() { return clothImageBase64; }
    public void setClothImageBase64(String clothImageBase64) { this.clothImageBase64 = clothImageBase64; }

    public String getGeneratedImageBase64() { return generatedImageBase64; }
    public void setGeneratedImageBase64(String generatedImageBase64) { this.generatedImageBase64 = generatedImageBase64; }

    public String getFitMatch() { return fitMatch; }
    public void setFitMatch(String fitMatch) { this.fitMatch = fitMatch; }

    public String getFitReason() { return fitReason; }
    public void setFitReason(String fitReason) { this.fitReason = fitReason; }

    public Integer getFitScore() { return fitScore; }
    public void setFitScore(Integer fitScore) { this.fitScore = fitScore; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}