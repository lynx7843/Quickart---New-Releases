package com.aimirror.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

@Service
public class GeminiService {

    @Value("${gemini.api.key}")
    private String geminiApiKey;

    private final ObjectMapper mapper = new ObjectMapper();
    private final HttpClient httpClient = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(30))
            .build();

    private static final String BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/";

    // ─────────────────────────────────────────────────────────
    //  STEP 1 : Analyze size fit using gemini-2.5-flash
    // ─────────────────────────────────────────────────────────
    public Map<String, Object> analyzeSizeFit(String userImageBase64,
                                              String clothImageBase64,
                                              String selectedSize) throws Exception {

        String prompt = String.format(
                "Analyze the person in the first image and the garment in the second image. " +
                        "The user is trying to wear size %s. " +
                        "Compare the person's body proportions with the garment's style and size. " +
                        "Return a JSON object ONLY with no extra text: " +
                        "{ \"match\": \"Perfect\" | \"Tight\" | \"Loose\", \"reason\": \"brief explanation\", \"score\": 0-100 }",
                selectedSize
        );

        // Build Gemini request body
        ObjectNode body = mapper.createObjectNode();
        ArrayNode contents = body.putArray("contents");
        ObjectNode content = contents.addObject();
        ArrayNode parts = content.putArray("parts");

        // Text part
        parts.addObject().put("text", prompt);

        // User image part
        ObjectNode userImgPart = parts.addObject();
        ObjectNode userInlineData = userImgPart.putObject("inlineData");
        userInlineData.put("mimeType", "image/png");
        userInlineData.put("data", stripDataPrefix(userImageBase64));

        // Cloth image part
        ObjectNode clothImgPart = parts.addObject();
        ObjectNode clothInlineData = clothImgPart.putObject("inlineData");
        clothInlineData.put("mimeType", "image/png");
        clothInlineData.put("data", stripDataPrefix(clothImageBase64));

        // Force JSON output
        ObjectNode genConfig = body.putObject("generationConfig");
        genConfig.put("responseMimeType", "application/json");

        String url = BASE_URL + "gemini-2.5-flash:generateContent?key=" + geminiApiKey;
        String responseBody = postToGemini(url, body.toString());

        JsonNode root = mapper.readTree(responseBody);
        String jsonText = root.path("candidates").get(0)
                .path("content").path("parts").get(0)
                .path("text").asText();

        JsonNode result = mapper.readTree(jsonText);
        Map<String, Object> analysis = new HashMap<>();
        analysis.put("match",  result.path("match").asText("Perfect"));
        analysis.put("reason", result.path("reason").asText(""));
        analysis.put("score",  result.path("score").asInt(75));
        return analysis;
    }

    // ─────────────────────────────────────────────────────────
    //  STEP 2 : Generate virtual try-on image
    // ─────────────────────────────────────────────────────────
    public String generateTryOnImage(String userImageBase64,
                                     String clothImageBase64,
                                     String selectedSize) throws Exception {

        String prompt = String.format(
                "A high-quality photo of the person from the original image realistically wearing " +
                        "the exact clothing item provided in the second image. " +
                        "Ensure the fit matches a %s size on their body. " +
                        "High fashion photography style, seamless integration.",
                selectedSize
        );

        ObjectNode body = mapper.createObjectNode();
        ArrayNode contents = body.putArray("contents");
        ObjectNode content = contents.addObject();
        ArrayNode parts = content.putArray("parts");

        parts.addObject().put("text", prompt);

        ObjectNode userImgPart = parts.addObject();
        ObjectNode userInlineData = userImgPart.putObject("inlineData");
        userInlineData.put("mimeType", "image/png");
        userInlineData.put("data", stripDataPrefix(userImageBase64));

        ObjectNode clothImgPart = parts.addObject();
        ObjectNode clothInlineData = clothImgPart.putObject("inlineData");
        clothInlineData.put("mimeType", "image/png");
        clothInlineData.put("data", stripDataPrefix(clothImageBase64));

        ObjectNode genConfig = body.putObject("generationConfig");
        ArrayNode modalities = genConfig.putArray("responseModalities");
        modalities.add("TEXT");
        modalities.add("IMAGE");

        // Use the image generation model
        String url = BASE_URL + "gemini-2.0-flash-exp-image-generation:generateContent?key=" + geminiApiKey;
        String responseBody = postToGemini(url, body.toString());

        JsonNode root = mapper.readTree(responseBody);
        JsonNode partsArray = root.path("candidates").get(0)
                .path("content").path("parts");

        for (JsonNode part : partsArray) {
            if (part.has("inlineData")) {
                String base64Data = part.path("inlineData").path("data").asText();
                String mimeType   = part.path("inlineData").path("mimeType").asText("image/png");
                return "data:" + mimeType + ";base64," + base64Data;
            }
        }
        throw new RuntimeException("No image was returned by Gemini.");
    }

    // ─────────────────────────────────────────────────────────
    //  HTTP helper
    // ─────────────────────────────────────────────────────────
    private String postToGemini(String url, String jsonBody) throws Exception {
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(jsonBody))
                .timeout(Duration.ofSeconds(120))
                .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() != 200) {
            throw new RuntimeException("Gemini API error " + response.statusCode() + ": " + response.body());
        }
        return response.body();
    }

    // Strip "data:image/png;base64," prefix if present
    private String stripDataPrefix(String base64) {
        if (base64 != null && base64.contains(",")) {
            return base64.split(",", 2)[1];
        }
        return base64;
    }
}