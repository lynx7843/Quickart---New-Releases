package com.aimirror;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AiMirrorApplication {
    public static void main(String[] args) {
        SpringApplication.run(AiMirrorApplication.class, args);
    }
}