package com.aimirror.dto;

public class TryOnResponse {

    private String sessionId;
    private String fitMatch;          // "Perfect", "Tight", "Loose"
    private String fitReason;
    private Integer fitScore;
    private String generatedImageBase64;  // data URI of AI-generated image
    private String message;

    // ---------- Getters & Setters ----------
    public String getSessionId() { return sessionId; }
    public void setSessionId(String sessionId) { this.sessionId = sessionId; }

    public String getFitMatch() { return fitMatch; }
    public void setFitMatch(String fitMatch) { this.fitMatch = fitMatch; }

    public String getFitReason() { return fitReason; }
    public void setFitReason(String fitReason) { this.fitReason = fitReason; }

    public Integer getFitScore() { return fitScore; }
    public void setFitScore(Integer fitScore) { this.fitScore = fitScore; }

    public String getGeneratedImageBase64() { return generatedImageBase64; }
    public void setGeneratedImageBase64(String generatedImageBase64) { this.generatedImageBase64 = generatedImageBase64; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
}