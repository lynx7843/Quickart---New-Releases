package com.aimirror.controller;

import com.aimirror.dto.TryOnRequest;
import com.aimirror.dto.TryOnResponse;
import com.aimirror.model.TryOnSession;
import com.aimirror.service.TryOnService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/tryon")
@CrossOrigin(origins = "*")   // ← Allow React dev server; tighten in production
public class TryOnController {

    private final TryOnService tryOnService;

    public TryOnController(TryOnService tryOnService) {
        this.tryOnService = tryOnService;
    }

    // ─────────────────────────────────────────────────────────
    //  POST /api/v1/tryon/fit
    //  Body: { userImageBase64, clothImageBase64, selectedSize }
    // ─────────────────────────────────────────────────────────
    @PostMapping("/fit")
    public ResponseEntity<TryOnResponse> runFitting(@RequestBody TryOnRequest request) {
        if (request.getUserImageBase64() == null || request.getClothImageBase64() == null) {
            TryOnResponse err = new TryOnResponse();
            err.setMessage("userImageBase64 and clothImageBase64 are required.");
            return ResponseEntity.badRequest().body(err);
        }
        TryOnResponse response = tryOnService.runVirtualFitting(request);
        return ResponseEntity.ok(response);
    }

    // ─────────────────────────────────────────────────────────
    //  GET /api/v1/tryon/sessions
    //  Returns all saved sessions (newest first)
    // ─────────────────────────────────────────────────────────
    @GetMapping("/sessions")
    public ResponseEntity<List<TryOnSession>> getAllSessions() {
        return ResponseEntity.ok(tryOnService.getAllSessions());
    }

    // ─────────────────────────────────────────────────────────
    //  GET /api/v1/tryon/sessions/{id}
    // ─────────────────────────────────────────────────────────
    @GetMapping("/sessions/{id}")
    public ResponseEntity<TryOnSession> getSession(@PathVariable String id) {
        try {
            return ResponseEntity.ok(tryOnService.getSessionById(id));
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // ─────────────────────────────────────────────────────────
    //  DELETE /api/v1/tryon/sessions/{id}
    // ─────────────────────────────────────────────────────────
    @DeleteMapping("/sessions/{id}")
    public ResponseEntity<Void> deleteSession(@PathVariable String id) {
        tryOnService.deleteSession(id);
        return ResponseEntity.noContent().build();
    }

    // ─────────────────────────────────────────────────────────
    //  GET /api/v1/tryon/health
    // ─────────────────────────────────────────────────────────
    @GetMapping("/health")
    public ResponseEntity<String> health() {
        return ResponseEntity.ok("AI Mirror backend is running ✓");
    }
}